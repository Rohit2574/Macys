﻿
/*
 * Created by SharpDevelop.
 * User: Rohit Kumar
 * Date: 13-06-2022
 */

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using IndicatorClass;
using ScrapingHelp;

namespace macys
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}
		
		string _WebsiteUrl = ConfigurationManager.AppSettings["WebsiteUrl"];
		int _WebsiteId = Convert.ToInt32(ConfigurationManager.AppSettings["Websiteid"]);
		string _JobNumber = ConfigurationManager.AppSettings["JobNumber"];
		string _Zip = ConfigurationManager.AppSettings["Zip"];
        string _MainCategoryTable = ConfigurationManager.AppSettings["MainCategoryTable"];
        string _MainlinkTable = ConfigurationManager.AppSettings["MainlinkTable"];
		string _DataTable = ConfigurationManager.AppSettings["DataTable"];
		string _productlinkTable = ConfigurationManager.AppSettings["ProductlinkTable"];
		string StoreId = ConfigurationManager.AppSettings["StoreId"];
		string Cookie = ConfigurationManager.AppSettings["Cookie"];
		
		Webscrape.WebScrapeSqlClass _ObjSql = new Webscrape.WebScrapeSqlClass();
		int Counter = 0;
		int ValidCounter=0;
		
		static bool AllwaysGoodCertificate(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors policyErrors)
		{
			return true;
		}
		
		public string GetSource(string url)
		{
			try
			{
				ServicePointManager.ServerCertificateValidationCallback += new RemoteCertificateValidationCallback(AllwaysGoodCertificate);
				ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
				HttpWebRequest myWebRequest = (HttpWebRequest)HttpWebRequest.Create(url);
				myWebRequest.KeepAlive = true;
				myWebRequest.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
				myWebRequest.Method = WebRequestMethods.Http.Get;
				myWebRequest.Headers["Cookie"]= Cookie;
				myWebRequest.AllowAutoRedirect = true;
				myWebRequest.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
				myWebRequest.Headers["Accept-Language"] = "en-US,en;q=0.9";
				myWebRequest.Headers["Upgrade-Insecure-Requests"]="1";
				myWebRequest.Headers["sec-fetch-dest"]="document";
				myWebRequest.Headers["sec-fetch-mode"]="navigate";
				myWebRequest.UserAgent= "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36";
				myWebRequest.Timeout = Timeout.Infinite;
				HttpWebResponse myWebResponse = (HttpWebResponse)myWebRequest.GetResponse();
				Stream responseStream = myWebResponse.GetResponseStream();
				StreamReader myWebSource = new StreamReader(responseStream, Encoding.UTF8);
				string myPageSource = myWebSource.ReadToEnd();
				myWebResponse.Close();
				responseStream.Close();
				return HtmlHelper.ReturnFormatedHtml(myPageSource);
			}
			catch (Exception ex)
			{
				return string.Empty;
			}
		}
		
		void Button1Click(object sender, EventArgs e)
		{
			const string url = "https://www.macys.com/xapi/navigate/v1/header?_regionCode=US&_deviceType=Desktop";
		retry:
			string source = GetSource(url);
			if (source == string.Empty || source.Contains("<TITLE>Access Denied</TITLE>") || source.Contains("<META NAME=\"robots") || source.Contains("<META NAME=\"ROBOTS\""))
				goto retry;
			
			string SubSource = "\"menu\":["+HtmlHelper.ReturnValue(source+"@rohit","\"menu\":[","}@rohit").Trim();
			string[] CategoryLevel1 = SplitSourceByBracket(SubSource);
			for (int i = 1; i < CategoryLevel1.Length; i++)
			{
				string CategoryName = HtmlHelper.ReturnValue(CategoryLevel1[i],"\"text\":\"","\",").Trim();
				string Categorylink = _WebsiteUrl + HtmlHelper.ReturnValue(CategoryLevel1[i],"\"url\":\"","\",").Trim();
				_ObjSql.InsertMainCategory(Convert.ToInt32(_WebsiteId),CategoryName,Categorylink,_Zip,"False","",_JobNumber,"");
				this.Text = "MainCategory: " + (++Counter);
			}
			Environment.Exit(-1);
		}		
		public string[] SplitSourceByBracket(string text)
		{
			int br1 = 0;
			bool FirstBracket= true;
			StringBuilder rr = new StringBuilder();
			List<string> result = new List<string>();
			for (int i = 0; i < text.Length-1; i++)
			{
				if(FirstBracket)
				{
					rr.Append(text[i]);
					if (text[i] == '[' ||  text[i] == '{')
					{
						FirstBracket=false;
						result.Add(rr.ToString());
						rr = rr.Remove(0, rr.Length);
					}
				}
				else
				{
					if (text[i] == '[' ||  text[i] == '{')
					{
						rr.Append(text[i]);
						br1++;
					}
					else if (text[i] == ']' || text[i] == '}')
					{
						br1--;
						if (br1 == 0)
						{
							rr.Append(text[i]);
							br1 = 0;
							result.Add(rr.ToString());
							rr = rr.Remove(0, rr.Length);
						}
						else
						{
							rr.Append(text[i]);
						}
					}
					else if (i == text.Length - 2)
					{
						rr.Append(text[i]);
						br1 = 0;
						result.Add(rr.ToString());
						rr = rr.Remove(0, rr.Length);
					}
					else
					{
						rr.Append(text[i]);
					}
				}
			}
			return result.ToArray();
		}
		
		void Timer1Tick(object sender, EventArgs e)
		{
			timer1.Stop();
			
			if(Convert.ToBoolean(ConfigurationManager.AppSettings["CategoryLink"]))
				button1.PerformClick();
			if(Convert.ToBoolean(ConfigurationManager.AppSettings["Mainlink"]))
				button2.PerformClick();
			if(Convert.ToBoolean(ConfigurationManager.AppSettings["Productlink"]))
				button3.PerformClick();
			if(Convert.ToBoolean(ConfigurationManager.AppSettings["Data"]))
				button4.PerformClick();
			
			Environment.Exit(-1);
		}
		
		void Button2Click(object sender, EventArgs e)
		{
		back1:
			DataTable dt = _ObjSql.ReturnDataTable("Select * from "+ _MainCategoryTable + " where websiteid='"+_WebsiteId+"' And iscomplete='False' and zip='"+_Zip+"' and extra1='"+_JobNumber+"' order by id");
			foreach(DataRow dr in dt.Rows)
			{
				string Mainlink = dr["Categorylink"].ToString();
				string id = dr["Id"].ToString();
				string category = System.Globalization.CultureInfo.InvariantCulture.TextInfo.ToTitleCase(dr["Category"].ToString().ToLower());
			retry1:
				string source = GetSource(Mainlink);
				if (source == string.Empty || source.Contains("<TITLE>Access Denied</TITLE>") || source.Contains("<META NAME=\"robots") || source.Contains("<META NAME=\"ROBOTS\""))
					goto retry1;
				
				if(source.Contains("\"itemCount\":"))
				{
					string TotalCount = HtmlHelper.ReturnValue(source,"\"itemCount\":",",");
					_ObjSql.UpdateDeleteInsert("Update mainlink set iscomplete='Valid',totalcount='"+TotalCount+"' where id='"+id+"'");
					this.Text = "Valid: "+(++ValidCounter);
				}
				else if(source.Contains("<div id=\"categoryTree\""))
				{
					if(category=="Jewelry" || category=="Men")
					{
						string[] SubSource = HtmlHelper.CollectUrl(source,"","<h5 class=\"accordion-header","</ul>");
						for (int j = 0; j < SubSource.Length; j++)
						{
							string Pcat = HtmlHelper.ReturnValue(SubSource[j],"title\">","</").Trim();
							string[] Cat = HtmlHelper.CollectUrl(SubSource[j],"","<li","</li>");
							for (int i = 0; i < Cat.Length; i++)
							{
								string CatName = HtmlHelper.ReturnValue(Cat[i],"<a href=\"",">","<").Trim();
								string CatLink = HtmlHelper.ReturnValue(Cat[i],"<a href=\"","\"").Trim();
								_ObjSql.InsertMainLink(_WebsiteId,3,_Zip,CatLink,category+">"+Pcat+">"+CatName,"","","","","","","","","","Valid","",_JobNumber,"","");
								this.Text = "Mainlink: "+(++Counter);
							}
						}
						
						_ObjSql.UpdateDeleteInsert("Update "+ _MainCategoryTable + " set iscomplete='True' where id='"+id+"'");
					}
					
					else
					{
						string SubSource = HtmlHelper.ReturnValue(source,"<ul class=\"categoryChildren\">", "</div></div></li></ul></div></div></div>");
						string[] Cat = HtmlHelper.CollectUrl(SubSource,"","<li","</li>");
						for (int i = 0; i < Cat.Length; i++)
					  	{
							string CatName = HtmlHelper.ReturnValue(Cat[i],"<a href=\"",">","<").Trim();
							string CatLink = HtmlHelper.ReturnValue(Cat[i],"<a href=\"","\"").Trim();
							_ObjSql.InsertMainLink(_WebsiteId,3,_Zip,CatLink,category+">"+CatName,"","","","","","","","","","Valid","",_JobNumber,"","");
							this.Text = "Mainlink: "+(++Counter);
						}
						_ObjSql.UpdateDeleteInsert("Update "+ _MainCategoryTable + " set iscomplete='True' where id='"+id+"'");
					}
				}
			}
			if(dt.Rows.Count==0)
				Environment.Exit(-1);
			else
				goto back1;
		}
		
		void Button3Click(object sender, EventArgs e)
		{ 
			string[] args=Environment.GetCommandLineArgs();
			string _Fid=args[1].Split('_').First();
			string _Lid=args[1].Split('_').Last();
			DataTable dt = _ObjSql.ReturnDataTable("Select * from "+_MainlinkTable+" where websiteid='"+_WebsiteId+"' And iscomplete='Valid' and zip='"+_Zip+"' and extra1='"+_JobNumber+"' And Id between "+_Fid+" and "+_Lid+ " order by id");
			foreach(DataRow dr in dt.Rows)
			{
				string mainlink = dr["MainLink"].ToString().Replace("https://www.macys.com","");
				string linksId = HtmlHelper.ReturnValue(mainlink,"id=","&");
				if(linksId==string.Empty)
					linksId = HtmlHelper.ReturnValue(mainlink+"&&&&&","id=","&&&&&");
				string id = dr["Id"].ToString();
				mainlink = mainlink.Split('?').First();
				string category = System.Globalization.CultureInfo.InvariantCulture.TextInfo.ToTitleCase(dr["Cat1"].ToString().ToLower()).Replace("'","''");
				int noofpages = 1;
				string totalCount = string.Empty;
				
				for (int i = 1; i <= noofpages; i++)
				{
				updateFormattedmainlnk:
					string Formatttedurl = "https://www.macys.com/xapi/discover/v1/page?pathname="+mainlink+"/Upc_bops_purchasable/"+StoreId+"&_additionalStoreLocations="+StoreId+"&id="+linksId+"&_application=SITE&_navigationType=BROWSE&_deviceType=DESKTOP&_shoppingMode=SITE&_regionCode=US&_customerExperiment=664-25,786-21,796-20,894-20&currencyCode=USD&_customerState=GUEST&pageIndex="+i+"&productsPerPage=120&sortBy=ORIGINAL&_shipFromLocations="+StoreId+"&sessionId=01813e65fc7d00146473a9a2b62e0506f00160670086e&userid=31714028763&visitorId=41638240989358866162884964234594670397&size=medium";
					if(Convert.ToBoolean(ConfigurationManager.AppSettings["withoutstorespecific"]))
						Formatttedurl = "https://www.macys.com/xapi/discover/v1/page?pathname="+mainlink+"&id="+linksId+"&_application=SITE&_navigationType=BROWSE&_deviceType=DESKTOP&_shoppingMode=SITE&_regionCode=US&_customerExperiment=664-25,786-21,796-20,894-20&currencyCode=USD&_customerState=GUEST&pageIndex="+i+"&productsPerPage=120&sortBy=ORIGINAL&sessionId=0181a4d6ee43007ae6f29f20cbb40506f00160670086e&visitorId=25578171094826936976707973222056159653&size=medium";
				retry1:
					string Source = GetSource(Formatttedurl);
					if (Source == string.Empty || Source.Contains("<TITLE>Access Denied</TITLE>") || Source.Contains("<META NAME=\"robots") || Source.Contains("<META NAME=\"ROBOTS\""))
						goto retry1;
					
					if(Source.Contains("redirect"))
					{
						linksId = HtmlHelper.ReturnValue(Source,"\"url\":\"","?id=","\",").Trim();
						mainlink = HtmlHelper.ReturnValue(Source,"\"url\":\"","\",").Split('?').First().Trim();
						goto updateFormattedmainlnk;
					}
					else
					{
						if(i==1)
						{
							totalCount = HtmlHelper.ReturnValue(Source,"\"searchResults\":\"","\"").Trim();
							if(totalCount!=string.Empty)
								noofpages = HtmlHelper.ReturnNumberOfPages(Convert.ToInt32(totalCount),120);
						}
						
						HtmlHelper.LogHtml(Source,category+"_"+i);
						string[] ProductIds = HtmlHelper.ReturnValue(Source,"\"productID\":[","]").Trim().Replace("\"","").Split(',');
						foreach (string ProductId in ProductIds)
						{
							string Insertquery="Insert into "+_productlinkTable+"(Websiteid,Zip,MainLink,Cat1,Iscomplete,Extra1,Extra2,Extra3) values" +"('"+_WebsiteId+"','"+_Zip+"','"+ProductId+"','"+category+"','False','"+_JobNumber+"','"+id+"','')";
							_ObjSql.UpdateDeleteInsert(Insertquery);
							this.Text = "ProductLink: "+(++Counter);
						}
					}
				}
				_ObjSql.UpdateDeleteInsert("Update "+_MainlinkTable+" set iscomplete='True',totalcount='"+totalCount+"' where id='"+id+"'");
			}
			Environment.Exit(-1);
		}
		
		void Button4Click(object sender, EventArgs e)
		{
			string[] args=Environment.GetCommandLineArgs();
			string _Fid=args[1].Split('_').First();
			string _Lid=args[1].Split('_').Last();
			string CollectMainLinks="Select * from "+_productlinkTable+" where websiteid='"+_WebsiteId+"' And iscomplete='False' and zip='"+_Zip+"' and extra1='"+_JobNumber+"' And Id between "+_Fid+" and "+_Lid+ " order by id";
			DataTable dt=_ObjSql.ReturnDataTable(CollectMainLinks);
			foreach(DataRow dr in dt.Rows)
			{
				string links = dr["MainLink"].ToString();
				string id = dr["id"].ToString();
				string category = dr["cat1"].ToString();
				string Formatttedurl = "https://www.macys.com/xapi/discover/v1/product?productIds="+links+"&_regionCode=US";
				string NewFormatttedurl = "https://www.macys.com/xapi/digital/v1/product/"+links+"?_customerState=GUEST&_regionCode=US&currencyCode=USD&_deviceType=DESKTOP&_shoppingMode=SITE&bigTicketCXHeaders=1&_application=SITE&_csLocation="+StoreId;
				if(Convert.ToBoolean(ConfigurationManager.AppSettings["withoutstorespecific"]))
					NewFormatttedurl = "https://www.macys.com/xapi/digital/v1/product/"+links+"?_customerState=GUEST&_regionCode=US&currencyCode=USD&_deviceType=DESKTOP&_shoppingMode=SITE&bigTicketCXHeaders=1&_application=SITE";
			retry1:
				string Source = GetSource(Formatttedurl);
				if (Source == string.Empty || Source.Contains("<TITLE>Access Denied</TITLE>") || Source.Contains("<META NAME=\"robots") || Source.Contains("<META NAME=\"ROBOTS\""))
					goto retry1;
				
			retry2:
				string NewSource = GetSource(NewFormatttedurl);
				if (NewSource == string.Empty || NewSource.Contains("<TITLE>Access Denied</TITLE>") || NewSource.Contains("<META NAME=\"robots") || NewSource.Contains("<META NAME=\"ROBOTS\""))
					goto retry2;

				DataDetails(Source,links,category,NewSource);
				_ObjSql.UpdateDeleteInsert("Update "+_productlinkTable+" set iscomplete='True' where id='"+id+"'");
			}
			
			Environment.Exit(-1);
		}
		
		public void DataDetails(string Source,string links,string category,string NewSource)
		{
			HtmlHelper.LogHtml(Source,links);
			if(Source.Contains("\"memberProducts\":["))
			{
				string CollectionSourceDeatils = Source.Split(new String []{"\"relationships\":"},StringSplitOptions.None).First().Trim();
				string SubSource = HtmlHelper.ReturnValue(Source,"\"relationships\":","\"productType\":\"master\"}");
				string[] subsoruce = SplitSourceByBracket(SubSource);
				string[] subsoruce1 = SplitSourceByBracket(subsoruce[2]);
				for (int i = 1; i < subsoruce1.Length; i++)
				{
					string productSourceDeatils = subsoruce1[i].Split(new String []{"\"relationships\":"},StringSplitOptions.None).First().Trim();
					string SubSource1111 = HtmlHelper.ReturnValue(subsoruce1[i],"\"relationships\":","\"productType\":\"member\"}");
					string[] subsoruce222 = SplitSourceByBracket(SubSource1111);
					string[] subsoruce333 = SplitSourceByBracket(subsoruce222[2]);
					for (int j = 1; j < subsoruce333.Length; j++)
					{
						DataExtract(subsoruce333[j],productSourceDeatils,CollectionSourceDeatils,links,category,NewSource);
						this.Text = "Data: "+(++Counter);
					}
				}
			}
			else
			{
				string productSourceDeatils = Source.Split(new String []{"\"relationships\":"},StringSplitOptions.None).First().Trim();
				string SubSource1111 = HtmlHelper.ReturnValue(Source,"\"relationships\":","\"productType\":");
				string[] subsoruce222 = SplitSourceByBracket(SubSource1111);
				string[] subsoruce333 = SplitSourceByBracket(subsoruce222[2]);
				for (int j = 1; j < subsoruce333.Length; j++)
				{
					DataExtract(subsoruce333[j],productSourceDeatils,"",links,category,NewSource);
					this.Text = "Data: "+(++Counter);
				}
			}
		}
		
		public void DataExtract(string VariantSource, string ProductSource, string CollectionSource,string links,string cat,string NewSource)
		{
			string site = string.Empty;
			string zip = string.Empty;
			string Date = string.Empty;
			string imagelink = string.Empty;
			string price = string.Empty;
			string Price_mult = string.Empty;
			string Eprice = string.Empty;
			string Eindicator = string.Empty;
			string altprice = string.Empty;
			string Altpricemult = string.Empty;
			string Ealtprice = string.Empty;
			string Altindicator = string.Empty;
			string pack = string.Empty;
			string unit = string.Empty;
			string uom = string.Empty;
			string size = string.Empty;
			string product_id = string.Empty;
			string upc = string.Empty;
			string asin = string.Empty;
			string category = string.Empty;
			string description = string.Empty;
			string note = string.Empty;
			string rating = string.Empty;
			string valid = string.Empty;
			string pageimage = string.Empty;
			string aisle = string.Empty;
			string orig_upc = string.Empty;
			string job_number = string.Empty;
			string sale_enddate = string.Empty;
			string Brand = string.Empty;
			string Extra1 = string.Empty;
			string Extra2 = string.Empty;
			string Extra3 = string.Empty;
			string Extra4 = string.Empty;
			string Extra5 = string.Empty;
			string Extra6 = string.Empty;
			string Extra7 = string.Empty;
			string Extra8 = string.Empty;
			string Extra9 = string.Empty;
			string LinkId = string.Empty;
			
			site = _WebsiteUrl;
			zip = _Zip;
			Date = DateTime.Now.ToShortDateString();
			job_number = _JobNumber;
			LinkId = links;
			
			imagelink = HtmlHelper.ReturnValue(VariantSource,"{\"filePath\":\"","\"");
			if(imagelink!=string.Empty)
				imagelink = "https://slimages.macysassets.com/is/image/MCY/products/"+imagelink;
			
			orig_upc = HtmlHelper.ReturnValue(VariantSource,"{\"id\":",",");
			if(orig_upc!=string.Empty)
				upc = orig_upc.Substring(0,orig_upc.Length-1);


            product_id = HtmlHelper.ReturnValue(VariantSource, "\"upcId\":\"", "\"").Trim();

            Extra8 = HtmlHelper.ReturnValue(ProductSource, "\"productId\":", ",\"").Replace("}", "").Trim();


            string RatingReviewSource = HtmlHelper.ReturnValue(ProductSource,"\"reviewStatistics\":{","}");
			rating = HtmlHelper.ReturnValue(RatingReviewSource,"rating\":",",\"").Trim();
			if(rating!=string.Empty)
				rating = Math.Round(Convert.ToDouble(rating),1).ToString();
			
			valid = HtmlHelper.ReturnValue(RatingReviewSource+"RAHUL","\"count\":","RAHUL");
			
			
			pageimage = HtmlHelper.ReturnValue(ProductSource,"\"productUrl\":\"","\"").Replace("'","''").Trim();
			if(pageimage!=string.Empty)
				pageimage = _WebsiteUrl+pageimage;
			
			note = HtmlHelper.ReturnValue(ProductSource,"\"brand\":\"","\",").Replace("'","''").Replace("&quot;","\"").Replace("&eacute;","e").Replace("&uuml;","u").Replace("&reg;","").Replace("™","").Replace("&nbsp;"," ").Replace("|","-").Trim();
			
			string catl1 = HtmlHelper.ReturnValue(ProductSource,"\"topLevelCategoryName\":\"","\",");
			string catl2 = HtmlHelper.ReturnValue(ProductSource,"\"categoryName\":\"","\",");
			if(catl1!=catl2)
				category = ("Macy's"+">"+catl1+">"+catl2).Replace("'","''");
			else
				category = ("Macy's"+">"+catl1).Replace("'","''");
			
			if(CollectionSource!=string.Empty)
			{
				category = string.Empty;
				catl1 = HtmlHelper.ReturnValue(CollectionSource,"\"topLevelCategoryName\":\"","\",");
				catl2 = HtmlHelper.ReturnValue(CollectionSource,"\"categoryName\":\"","\",");
				if(catl1!=catl2)
					category = ("Macy's"+">"+catl1+">"+catl2).Replace("'","''");
				else
					category = ("Macy's"+">"+catl1).Replace("'","''");
			}
			
			if(category=="Macy''s>")
			{
				string NewCategory = HtmlHelper.ReturnValue(NewSource,"\"taxonomy\":{\"categories\":[","]");
				category = category +string.Join(">",HtmlHelper.CollectUrl(NewCategory,"","\"name\":\"","\","));
			}
			
			if(category=="Macy''s>")
				category = "Macy''s";
			
			description = HtmlHelper.ReturnValue(ProductSource,"\"name\":\"","\",").Replace("'","''").Replace("&quot;","\"").Replace("&eacute;","e").Replace("&uuml;","u").Replace("&reg;","").Replace("™","").Replace("&nbsp;"," ").Replace("&egrave;","e").Trim();
			
			string PriceSource = HtmlHelper.ReturnValue(VariantSource,"\"pricing\":{","\"priceTypeId\"");
			sale_enddate = HtmlHelper.ReturnValue(PriceSource,"\"saleEnds\":\"","\",").Replace("'","''").Replace("Sale ends","").Trim();
			
			price = HtmlHelper.ReturnValue(PriceSource,"{\"label\":\"Sale","\"formattedValue\":\"","\"").Trim();
			if(price == string.Empty)
				price = HtmlHelper.ReturnValue(PriceSource,"{\"label\":\"Now","\"formattedValue\":\"","\"").Trim();
			if(price == string.Empty)
				price = HtmlHelper.ReturnValue(PriceSource,"{\"label\":\"","\"formattedValue\":\"","\"").Trim();
			
			altprice = HtmlHelper.ReturnValue(PriceSource,"{\"label\":\"Reg.","\"formattedValue\":\"","\"").Trim();
			if(altprice == string.Empty)
				altprice = HtmlHelper.ReturnValue(PriceSource,"{\"label\":\"Orig","\"formattedValue\":\"","\"").Trim();

			string OfferPriceSource = HtmlHelper.ReturnValue(VariantSource,"finalPrice\":{","}").Trim();
			Extra1 = HtmlHelper.ReturnValue(OfferPriceSource,"\"formattedValue\":\"","\"").Trim();
			
			Dictionary<string, string> objind = Indicators.GetEquivalentValue(price, description);
			Price_mult = objind["EPack"].Replace("-","").Trim();
			Eprice = objind["EPrice"].Replace("-","").Trim();
			
			Dictionary<string, string> objind1 = Indicators.GetEquivalentValue(altprice, description);
			Altpricemult = objind1["EPack"].Replace("-","").Trim();
			Ealtprice = objind1["EPrice"].Replace("-","").Trim();
			Altindicator = string.Empty;
			
			WabScrapeUnit.MyClass ObjUnitUom =new WabScrapeUnit.MyClass();
			Dictionary<string, string> objunit = ObjUnitUom.Get_Size_Value_in_Unit_Uom(description);
			uom = objunit["Uom"].Trim();
			unit = objunit["Unit"].Trim();
			size = objunit["Size"].Trim();
			pack = objunit["Pack"].Trim();
			if(size!="")
			{
				objunit = ObjUnitUom.Get_Size_Value_in_Unit_Uom(size);
				uom = objunit["Uom"].Replace("-","").Trim();
				unit = objunit["Unit"].Trim();
				size= objunit["Size"].Trim();
			}
			
			string variantSubSource = HtmlHelper.ReturnValue(VariantSource,"\"traits\":{","},\"pricing\"");
			string [] variants = variantSubSource.Split(new String[]{"\"id\":"},StringSplitOptions.RemoveEmptyEntries);
			for (int i = 1; i < variants.Length; i++)
			{
				if(Extra2 == string.Empty)
					Extra2 =  HtmlHelper.ReturnValue(variants[i],"\"name\":\"","\",");
				else
					Extra2 =  Extra2 +", "+HtmlHelper.ReturnValue(variants[i],"\"name\":\"","\",");
			}
			
			Extra2 = Extra2.Replace(", No Size","").Replace("No Color","").Replace("No Size","");
			Extra3 = HtmlHelper.ReturnValue(CollectionSource,"\"productUrl\":\"","\"").Replace("'","''").Trim();
			Extra9 = cat.Replace("'","''");
			
			size = string.Empty;
			if(altprice==string.Empty)
				sale_enddate = string.Empty;
			
			if(description!=string.Empty && Extra2!=string.Empty)
				description = description +" "+Extra2;
			
			if (sale_enddate != string.Empty)

			{
				Eindicator = Eindicator.Replace("*","");
				sale_enddate = Convert.ToDateTime(sale_enddate).ToString("MM/dd/yyyy");
				DateTime date = DateTime.Now.Date;
				TimeSpan t;
				t = Convert.ToDateTime(sale_enddate) - date;
				int NrOfDays = t.Days;
				if (NrOfDays <= 29)
					Eindicator += "A";
				else
					Eindicator += "*";
				sale_enddate = Convert.ToDateTime(sale_enddate).ToString("MM/dd/yyyy");
			}
			//================================Updated=========================================================
			
			if(uom.Contains("Fo") || uom.Contains("FT6"))
			{
				unit=string.Empty;
				uom=string.Empty;
			}
			
			if((unit.Contains("-")) ||( unit.Length>4  && !unit.Contains("x") && !unit.Contains(".") && !unit.Contains("/")))
			{
				unit=string.Empty;
				uom=string.Empty;
			}
			
			if(uom.Contains("ftX"))
			{
				uom=uom.Replace("X","");
			}
			
			if(altprice!=string.Empty && !Eindicator.Contains("*") && sale_enddate==string.Empty)
			{
				Eindicator=Eindicator+"*";
			}
			
			category=category.Replace("Macy''s>","").Replace("Macy''s","").Replace("'","''");
			description=description.Replace("'","''").Replace("\t","").Replace("\\","").Replace("&ecirc;","e").Replace("&ocirc;","o").Replace("&eacute;","e").Replace("&icirc;","i").Replace("&iquest;","¿").Replace("nbsp;","").Replace("&commat;", "@").Replace("&egrave;", "e").Replace("&Eacute;", "E").Replace("&deg;", "°").Replace("&middot;", "·").Replace("&Ecirc;", "E");
			note=note.Replace("&ecirc;","e").Replace("&ocirc;","o").Replace("&eacute;","e").Replace("&icirc;","i").Replace("&iquest;","¿");
			
			_ObjSql.ProductDynamicDetailsInsert42(_DataTable,site,zip,Date,imagelink,price,Price_mult,Eprice,Eindicator,altprice,Altpricemult,Ealtprice,Altindicator,pack,unit,uom,size,product_id,upc,asin,category,description,note,rating,valid,pageimage,aisle,orig_upc,job_number,sale_enddate,Brand,Extra1,Extra2,Extra3,Extra4,Extra5,Extra6,Extra7,Extra8,Extra9,LinkId);
		}
	}
}