﻿using System;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ScrapingHelp;

namespace Webscrape
{

	public class WebScrapeSqlClass
	{
		private SqlConnection con = new SqlConnection();
		private SqlCommand _cmdInsertMainCategory = new SqlCommand();
		private SqlCommand _cmdInsertMainlink=new SqlCommand();
		private SqlCommand _cmdDynamicInsert42ProductDetails = new SqlCommand();
		private SqlCommand _cmdInsertRestaurantDetailDynamic = new SqlCommand();
		
			private void InitializeConnection()
	        {
	            try
	            {
	                if (this.con == null)
	                    this.con = new SqlConnection();
	
	                if (this.con.ConnectionString == string.Empty)
	                    con.ConnectionString = ConfigurationSettings.AppSettings["connectionString"];
	
	                if (this.con.State == ConnectionState.Closed || this.con.State == ConnectionState.Broken)
	                    con.Open();
	            }
	            catch (Exception se)
	            {
	               HtmlHelper.LogText(se.Message,"InitializeConnectionIssue"); 
	            }
	        }
			
			public SqlConnection OpenConnection
	        {
	            get
	            {
	                InitializeConnection();
	                return con;
	            }
	        }
			
			public void InitializeMainCategory()
	        {
	            try
	            {
	                if (this.con.State == ConnectionState.Closed || this.con.State == ConnectionState.Broken)
	                    this.con.Open();
	                _cmdInsertMainCategory.Connection = this.con;
	                _cmdInsertMainCategory.CommandText = "dbo.insertMainCategory";
	                _cmdInsertMainCategory.CommandType = CommandType.StoredProcedure;
	                _cmdInsertMainCategory.Parameters.Add("@Websiteid", SqlDbType.Int);
	                _cmdInsertMainCategory.Parameters.Add("@Date", SqlDbType.DateTime);
	                _cmdInsertMainCategory.Parameters.Add("@Category",SqlDbType.NVarChar);
					_cmdInsertMainCategory.Parameters.Add("@CategoryLink",SqlDbType.NVarChar);
					_cmdInsertMainCategory.Parameters.Add("@Zip",SqlDbType.NVarChar);
					_cmdInsertMainCategory.Parameters.Add("@Iscomplete",SqlDbType.NVarChar);
					_cmdInsertMainCategory.Parameters.Add("@TotalCount",SqlDbType.NVarChar);
					_cmdInsertMainCategory.Parameters.Add("@Extra1",SqlDbType.NVarChar);
					_cmdInsertMainCategory.Parameters.Add("@Extra2",SqlDbType.NVarChar);
	            }
	            catch (SqlException se)
	            {
	                HtmlHelper.LogText(se.Message,"InitializeMainCategoryIssue"); 
	            }
	            catch (Exception ee) 
	            {
	            	HtmlHelper.LogText(ee.Message,"InitializeMainCategoryIssue"); 
	            }
	        }
			
			public void InitializeMainLink()
	        {
	            try
	            {
	                if (this.con.State == ConnectionState.Closed || this.con.State == ConnectionState.Broken)
	                    this.con.Open();
	                _cmdInsertMainlink.Connection = this.con;
	                _cmdInsertMainlink.CommandText = "dbo.insertMainlink";
	                _cmdInsertMainlink.CommandType = CommandType.StoredProcedure;
	                _cmdInsertMainlink.Parameters.Add("@Date",SqlDbType.DateTime);
					_cmdInsertMainlink.Parameters.Add("@Websiteid",SqlDbType.Int);
					_cmdInsertMainlink.Parameters.Add("@MaincategoryId",SqlDbType.Int);
					_cmdInsertMainlink.Parameters.Add("@Zip",SqlDbType.NVarChar);
					_cmdInsertMainlink.Parameters.Add("@MainLink",SqlDbType.NVarChar);
					_cmdInsertMainlink.Parameters.Add("@Cat1",SqlDbType.NVarChar);
					_cmdInsertMainlink.Parameters.Add("@Cat2",SqlDbType.NVarChar);
					_cmdInsertMainlink.Parameters.Add("@Cat3",SqlDbType.NVarChar);
					_cmdInsertMainlink.Parameters.Add("@Cat4",SqlDbType.NVarChar);
					_cmdInsertMainlink.Parameters.Add("@Cat5",SqlDbType.NVarChar);
					_cmdInsertMainlink.Parameters.Add("@Cat6",SqlDbType.NVarChar);
					_cmdInsertMainlink.Parameters.Add("@Cat7",SqlDbType.NVarChar);
					_cmdInsertMainlink.Parameters.Add("@Cat8",SqlDbType.NVarChar);
					_cmdInsertMainlink.Parameters.Add("@Cat9",SqlDbType.NVarChar);
					_cmdInsertMainlink.Parameters.Add("@Cat10",SqlDbType.NVarChar);
					_cmdInsertMainlink.Parameters.Add("@Iscomplete",SqlDbType.NVarChar);
					_cmdInsertMainlink.Parameters.Add("@TotalCount",SqlDbType.NVarChar);
					_cmdInsertMainlink.Parameters.Add("@Extra1",SqlDbType.NVarChar);
					_cmdInsertMainlink.Parameters.Add("@Extra2",SqlDbType.NVarChar);
					_cmdInsertMainlink.Parameters.Add("@Extra3",SqlDbType.NVarChar);
			
	            }
	            catch (SqlException se)
	            {
	                HtmlHelper.LogText(se.Message,"InitializeMainLinkIssue"); 
	            }
	            catch (Exception ee) 
	            { 
	            	HtmlHelper.LogText(ee.Message,"InitializeMainLinkIssue");  
	            }
	        }
			
			public void InitializeDynamicProductDetails42()
			{
				try
				{
					if (this.con.State == ConnectionState.Closed || this.con.State == ConnectionState.Broken)
	                    this.con.Open();
					this._cmdDynamicInsert42ProductDetails.Connection = this.con;
					this._cmdDynamicInsert42ProductDetails.CommandText = "insert42detailDynamic";
					this._cmdDynamicInsert42ProductDetails.CommandType = CommandType.StoredProcedure;
				}
				catch (Exception ex)
				{
					HtmlHelper.LogText(ex.Message,"InitializeDynamicProductDetails42Issue"); 
				}
			}
			 
			public void InitializeInsertRestaurantDetailDynamic()
			{
				try
				{
					if (this.con.State == ConnectionState.Closed || this.con.State == ConnectionState.Broken)
	                    this.con.Open();
					this._cmdInsertRestaurantDetailDynamic.Connection = this.con;
					this._cmdInsertRestaurantDetailDynamic.CommandText = "InsertRestaurantDetailDynamic";
					this._cmdInsertRestaurantDetailDynamic.CommandType = CommandType.StoredProcedure;
				}
				catch (Exception ex)
				{
					HtmlHelper.LogText(ex.Message,"InitializeInsertRestaurantDetailDynamicIssue"); 
				}
			}
			
			
			
			public SqlCommand cmdInsertMainCategory
	        {
	            get
	            {
	                InitializeConnection();
	                _cmdInsertMainCategory.Parameters.Clear();
	                InitializeMainCategory();
	                return _cmdInsertMainCategory;
	            }
	        }
			
			public SqlCommand cmdInsertMainlink
			{
				get
				{
					InitializeConnection();
					_cmdInsertMainlink.Parameters.Clear();
					InitializeMainLink();
					return _cmdInsertMainlink;
				}
			}
			
			public SqlCommand cmdDynamicInsert42ProductDetails
			{
				get
				{
					InitializeConnection();
					_cmdDynamicInsert42ProductDetails.Parameters.Clear();
					InitializeDynamicProductDetails42();
					return _cmdDynamicInsert42ProductDetails;
				}
			}
			
			public SqlCommand cmdInsertRestaurantDetailDynamic
			{
				get
				{
					InitializeConnection();
					_cmdInsertRestaurantDetailDynamic.Parameters.Clear();
					InitializeInsertRestaurantDetailDynamic();
					return _cmdInsertRestaurantDetailDynamic;
				}
			}
			
			public int InsertMainCategory(int WebSiteID, string Category, string CategoryLink,string Zip,string Iscomplete,string TotalCount,string Extra1,string Extra2)
	        {
	            try
	            {
	                SqlCommand oCommandPro = cmdInsertMainCategory;
	                oCommandPro.Parameters["@WebSiteID"].Value = WebSiteID;
	                oCommandPro.Parameters["@Date"].Value = DateTime.Now;
	                oCommandPro.Parameters["@Category"].Value = Category;
	                oCommandPro.Parameters["@CategoryLink"].Value = CategoryLink;
	                oCommandPro.Parameters["@Zip"].Value = Zip;
	                oCommandPro.Parameters["@Iscomplete"].Value=Iscomplete;
	                oCommandPro.Parameters["@TotalCount"].Value=TotalCount;
	                oCommandPro.Parameters["@Extra1"].Value=Extra1;
	                oCommandPro.Parameters["@Extra2"].Value=Extra2;
	                return oCommandPro.ExecuteNonQuery();
	            }
	            catch (SqlException se) 
	            {
	            	HtmlHelper.LogText(se.Message,"InsertMainCategoryIssue"); 
	            	return 0;
	            }
	            catch (Exception ee) 
	            {
	            	HtmlHelper.LogText(ee.Message,"InsertMainCategoryIssue");
	            	return 0;
	            }
	        }
			
			public int InsertMainLink(int Websiteid,int MaincategoryId,string Zip,string MainLink,string Cat1,string Cat2,string Cat3,string Cat4,string Cat5,string Cat6,string Cat7,string Cat8,string Cat9,string Cat10,string Iscomplete,string TotalCount,string Extra1,string Extra2,string Extra3 )
			{
				try
	            {
					SqlCommand oCommandPro = cmdInsertMainlink;
					oCommandPro.Parameters["@Date"].Value=DateTime.Now;
					oCommandPro.Parameters["@Websiteid"].Value=Websiteid;
					oCommandPro.Parameters["@MaincategoryId"].Value=MaincategoryId;
					oCommandPro.Parameters["@Zip"].Value=Zip;
					oCommandPro.Parameters["@MainLink"].Value=MainLink;
					oCommandPro.Parameters["@Cat1"].Value=Cat1;
					oCommandPro.Parameters["@Cat2"].Value=Cat2;
					oCommandPro.Parameters["@Cat3"].Value=Cat3;
					oCommandPro.Parameters["@Cat4"].Value=Cat4;
					oCommandPro.Parameters["@Cat5"].Value=Cat5;
					oCommandPro.Parameters["@Cat6"].Value=Cat6;
					oCommandPro.Parameters["@Cat7"].Value=Cat7;
					oCommandPro.Parameters["@Cat8"].Value=Cat8;
					oCommandPro.Parameters["@Cat9"].Value=Cat9;
					oCommandPro.Parameters["@Cat10"].Value=Cat10;
					oCommandPro.Parameters["@Iscomplete"].Value=Iscomplete;
					oCommandPro.Parameters["@TotalCount"].Value=TotalCount;
					oCommandPro.Parameters["@Extra1"].Value=Extra1;
					oCommandPro.Parameters["@Extra2"].Value=Extra2;
					oCommandPro.Parameters["@Extra3"].Value=Extra3;
					return oCommandPro.ExecuteNonQuery();
				}
				catch (SqlException se) 
				{
					HtmlHelper.LogText(se.Message,"InsertMainLinkIssue");
					return 0;
				}
	            catch (Exception ee) 
	            { 
	            	HtmlHelper.LogText(ee.Message,"InsertMainLinkIssue");
	            	return 0;
	            }
			}
			

        	public void ProductDynamicDetailsInsert42(string TABLENAME, string site, string zip, string date, string imagelink, string price, string price_mult, string Eprice, string Eindicator, string altprice, string altpricemult, string Ealtprice, string altindicator, string pack, string unit, string uom, string size, string product_id, string upc, string asin, string category, string description, string note, string rating, string valid, string pageimage, string aisle, string orig_upc, string job_number, string sale_enddate, string brand, string extra1, string extra2, string extra3, string extra4, string extra5, string extra6, string extra7, string extra8, string extra9, string LinkID)
			{
				try
				{
					SqlConnection openConnection = this.OpenConnection;
					SqlCommand cmdDynamicInsert42ProductDetails = this.cmdDynamicInsert42ProductDetails;
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("TableName", TABLENAME);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("site", site);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("zip", zip);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("date", date);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("imagelink", imagelink);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("price", price);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("price_mult", price_mult);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("Eprice", Eprice);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("Eindicator", Eindicator);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("altprice", altprice);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("altpricemult", altpricemult);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("Ealtprice", Ealtprice);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("altindicator", altindicator);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("pack", pack);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("unit", unit);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("uom", uom);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("size", size);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("product_id", product_id);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("upc", upc);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("asin", asin);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("category", category);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("description", description);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("note", note);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("rating", rating);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("valid", valid);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("pageimage", pageimage);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("aisle", aisle);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("orig_upc", orig_upc);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("job_number", job_number);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("sale_enddate", sale_enddate);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("brand", brand);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("extra1", extra1);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("extra2", extra2);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("extra3", extra3);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("extra4", extra4);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("extra5", extra5);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("extra6", extra6);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("extra7", extra7);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("extra8", extra8);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("extra9", extra9);
					cmdDynamicInsert42ProductDetails.Parameters.AddWithValue("LinkID", LinkID);
					cmdDynamicInsert42ProductDetails.CommandTimeout = 0;
					cmdDynamicInsert42ProductDetails.ExecuteNonQuery();
				}
				catch (Exception ee)
				{
					HtmlHelper.LogText(ee.Message,"ProductDynamicDetailsInsert42Issue");
				}
			}
        
        	
        	public void InsertRestaurantDetail(string TABLENAME, string Retailer, string Restaurant_Name, string Address, string City, string State, string Zip, string Contact_No, string Restaurant_Rating, string Imagelink, string Short_Description, string Long_Description, string Variant, string UOM, string Type, string Type_Name, string Base_Price, string Variant_Price, string Total_Price, string Min_Order_Price, string Category, string Product_ID, string Job_Number, string Extra1, string Extra2, string Extra3, string Extra4, string Extra5, string Extra6, string Extra7, string Extra8, string Extra9, string LinkId)
			{
				try
				{
					SqlConnection openConnection = this.OpenConnection;
					SqlCommand CmdInsertRestaurantDetail = this.cmdInsertRestaurantDetailDynamic;
					CmdInsertRestaurantDetail.Parameters.AddWithValue("TableName", TABLENAME);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Retailer",Retailer);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Restaurant_Name",Restaurant_Name);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Address",Address);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("City",City);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("State",State);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Zip",Zip);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Contact_No",Contact_No);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Restaurant_Rating",Restaurant_Rating);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Imagelink",Imagelink);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Short_Description",Short_Description);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Long_Description",Long_Description);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Variant",Variant);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("UOM",UOM);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Type",Type);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Type_Name",Type_Name);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Base_Price",Base_Price);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Variant_Price",Variant_Price);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Total_Price",Total_Price);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Min_Order_Price",Min_Order_Price);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Category",Category);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Product_ID",Product_ID);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Job_Number",Job_Number);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Extra1",Extra1);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Extra2",Extra2);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Extra3",Extra3);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Extra4",Extra4);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Extra5",Extra5);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Extra6",Extra6);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Extra7",Extra7);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Extra8",Extra8);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("Extra9",Extra9);
					CmdInsertRestaurantDetail.Parameters.AddWithValue("LinkId",LinkId);
					CmdInsertRestaurantDetail.CommandTimeout = 0;
					CmdInsertRestaurantDetail.ExecuteNonQuery();
				}
				catch (Exception ex)
				{
					HtmlHelper.LogText(ex.Message,"InsertRestaurantDetailIssue");
				}
			}
        	
        	public DataTable ReturnDataTable(string _query)
	        {
	            SqlConnection oCon = OpenConnection;
	            SqlCommand cmdlink = new SqlCommand(_query);
	            cmdlink.Connection = oCon;
	            SqlDataAdapter drlink = new SqlDataAdapter(cmdlink);
	            DataTable dtlink = new DataTable();
	            drlink.Fill(dtlink);
	            return dtlink;
	        }
			
			
			public string ReturnString(string _query)
	        {
				string result=string.Empty;
	            SqlConnection oCon = OpenConnection;
	            SqlCommand cmdlink = new SqlCommand(_query);
	            cmdlink.Connection = oCon;
	            SqlDataAdapter drlink = new SqlDataAdapter(cmdlink);
	            DataTable dtlink = new DataTable();
	            drlink.Fill(dtlink);
	            if(dtlink.Rows.Count>0)
	            {
	            	result=dtlink.Rows[0][0].ToString();
	            }
	            return result;
	        }

			
	        public void UpdateDeleteInsert(string Query)
	        {
	            try
	            {
	                SqlConnection oCon = OpenConnection;
	                SqlCommand oCom = new SqlCommand(Query, oCon);
	                oCom.ExecuteScalar();
	            }
	            catch (Exception ex)
	            {
	            	HtmlHelper.LogText(Query,"UpdateDeleteInsertIssue");
	            }
	        }
        
	        public Boolean ReturnBoolean(string Query)
	        {
	            bool flag = false;
	            try
	            {
	                SqlConnection oCon = OpenConnection;
	                SqlCommand oCom = new SqlCommand(Query, oCon);
	                int count = ((int)oCom.ExecuteScalar());
	                if (count > 0)
	                    flag = true;
	            }
	            catch (Exception)
	            {
	
	            }
	            return flag;
	        }
        
	        public int ReturnInteger(string Query)
	        {
	            int Result = 0;
	            try
	            {
	                SqlConnection oCon = OpenConnection;
	                SqlCommand oCom = new SqlCommand(Query, oCon);
	                int count = ((int)oCom.ExecuteScalar());
	                if (count > 0)
	                    Result = count;
	            }
	            catch (Exception)
	            {
	
	            }
	            return Result;
	        }
        
		}
	}

